import pandas as pd
import joblib
import os
from sklearn.linear_model import SGDClassifier
from sklearn.preprocessing import LabelEncoder, StandardScaler

# Define paths
DATA_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(DATA_DIR, 'models')
os.makedirs(MODEL_DIR, exist_ok=True)

# 1. Load data
file_name = os.path.join(DATA_DIR, 'medicine_data.csv')
print(f"Loading data from: {file_name}")
df = pd.read_csv(file_name)

# 2. Encode categorical text into numbers
le_crop = LabelEncoder()
le_disease = LabelEncoder()
le_medicine = LabelEncoder()

print("Encoding data...")
df['crop_n'] = le_crop.fit_transform(df['Crop'])
df['disease_n'] = le_disease.fit_transform(df['Disease'])
y = le_medicine.fit_transform(df['Medicine Name'])

# 3. Features (X)
X = df[['crop_n', 'disease_n']]

# Scale the data
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 4. Train Model (SGDClassifier)
print("Training model...")
model = SGDClassifier(loss='log_loss', max_iter=1000, tol=1e-3, random_state=42)
model.fit(X_scaled, y)

# 5. Save Artifacts
print("Saving models to:", MODEL_DIR)
joblib.dump(model, os.path.join(MODEL_DIR, 'medicine_model.joblib'))
joblib.dump(scaler, os.path.join(MODEL_DIR, 'medicine_scaler.joblib'))
joblib.dump(le_crop, os.path.join(MODEL_DIR, 'le_crop.joblib'))
joblib.dump(le_disease, os.path.join(MODEL_DIR, 'le_disease.joblib'))
joblib.dump(le_medicine, os.path.join(MODEL_DIR, 'le_medicine.joblib'))

print("Training complete and models saved!")

# Verification Test
test_crop = "Tomato"
test_disease = "Late Blight"
try:
    c_code = le_crop.transform([test_crop])[0]
    d_code = le_disease.transform([test_disease])[0]
    sample_scaled = scaler.transform([[c_code, d_code]])
    prediction_id = model.predict(sample_scaled)
    recommended_medicine = le_medicine.inverse_transform(prediction_id)[0]
    print(f"Test Prediction -> Crop: {test_crop}, Disease: {test_disease}, Rec: {recommended_medicine}")
except Exception as e:
    print(f"Test failed: {e}")
