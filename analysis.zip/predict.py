import sys
import os

# Add the soil directory to the system path to import modules from it
sys.path.append(os.path.join(os.path.dirname(__file__), 'soil'))

try:
    from fertilizer_rules import get_recommendation
except ImportError:
    print("Error: Could not import 'fertilizer_rules'. Make sure you are running this script from 'D:\\SIH\\NITR\\data2'.")
    sys.exit(1)

def get_float_input(prompt):
    while True:
        try:
            value = float(input(prompt))
            return value
        except ValueError:
            print("Invalid input. Please enter a numeric value.")

def get_choice_input(prompt, options):
    while True:
        value = input(prompt).strip().title()
        if value in options:
            return value
        print(f"Invalid input. Please choose from: {', '.join(options)}")

def predict_structure():
    print("\n==============================================")
    print("🌱 Soil Nutrient & Crop Recommendation System")
    print("==============================================\n")
    print("Please enter the soil details from your lab report or estimation:\n")

    # 1. Get User Input
    n_val = get_float_input("Enter Nitrogen (N) content [ppm]: ")
    p_val = get_float_input("Enter Phosphorus (P) content [ppm]: ")
    k_val = get_float_input("Enter Potassium (K) content [ppm]: ")
    ph_val = get_float_input("Enter pH Level (0-14): ")
    oc_val = get_choice_input("Enter Organic Carbon Level (Low, Medium, High): ", ['Low', 'Medium', 'High'])

    # 2. Classify (Rule-Based for demo, simulating model interpretation)
    # Using thresholds defined in judge_soil.py
    status = {}
    
    # Nitrogen Classification
    if n_val < 200: status['Nitrogen'] = 'Low'
    elif n_val < 350: status['Nitrogen'] = 'Medium'
    else: status['Nitrogen'] = 'High'
    
    # Phosphorus Classification
    if p_val < 20: status['Phosphorus'] = 'Low'
    elif p_val < 50: status['Phosphorus'] = 'Medium'
    else: status['Phosphorus'] = 'High'
    
    # Potassium Classification
    if k_val < 150: status['Potassium'] = 'Low'
    elif k_val < 300: status['Potassium'] = 'Medium'
    else: status['Potassium'] = 'High'

    print("\n----------------------------------------------")
    print(f"🔬 Analysis Summary:")
    print(f"   • Nitrogen Status:   {status['Nitrogen']} ({n_val} ppm)")
    print(f"   • Phosphorus Status: {status['Phosphorus']} ({p_val} ppm)")
    print(f"   • Potassium Status:  {status['Potassium']} ({k_val} ppm)")
    print(f"   • pH Level:          {ph_val}")
    print(f"   • Organic Carbon:    {oc_val}")
    print("----------------------------------------------")

    # 3. Generate Recommendations
    soil_cond = {'pH': ph_val, 'OC': oc_val}
    recs = get_recommendation(status, soil_cond)

    # 4. Display Report
    print("\n📋 ADVISORY REPORT")
    
    print("\n[A] 🌾 SUITABLE CROPS:")
    if recs['crop_recs']:
        for c in recs['crop_recs']:
            print(f"   • {c['name']:<15} | Season: {c['season']:<15} | Tip: {c['tips']}")
    else:
        print("   • No specific crop recommendations for these extreme conditions.")

    print("\n[B] 💊 FERTILIZER RECOMMENDATIONS:")
    if recs['fertilizer_recs']:
        for r in recs['fertilizer_recs']:
            print(f"   • {r}")
    else:
        print("   • No specific fertilizer actions needed.")

    print("\n[C] 💡 EFFICIENCY TIPS:")
    for t in recs['efficiency_tips']:
        print(f"   • {t}")
    
    print("\n==============================================")

if __name__ == "__main__":
    while True:
        predict_structure()
        cont = input("\nAnalyze another sample? (y/n): ").lower()
        if cont != 'y':
            break
