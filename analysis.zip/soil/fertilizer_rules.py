
def get_recommendation(nutrient_status, soil_conditions):
    """
    Inputs:
        nutrient_status (dict): {'Nitrogen': 'Low', 'Phosphorus': 'High', ...}
        soil_conditions (dict): {'pH': 6.5, 'OC': 'Low'}
    
    Returns:
        dict: {
            'fertilizer_recs': [...],
            'crop_recs': [...],
            'efficiency_tips': [...]
        }
    """
    recommendations = {
        'fertilizer_recs': [],
        'crop_recs': [],
        'efficiency_tips': []
    }
    
    # --- 1. Fertilizer Recommendations ---
    if nutrient_status.get('Nitrogen') == 'Low':
        recommendations['fertilizer_recs'].append("Nitrogen Deficiency: Apply Urea @ 60kg/acre.")
    elif nutrient_status.get('Nitrogen') == 'Medium':
        recommendations['fertilizer_recs'].append("Nitrogen Moderate: Apply Urea @ 30kg/acre for maintenance.")
        
    if nutrient_status.get('Phosphorus') == 'Low':
        recommendations['fertilizer_recs'].append("Phosphorus Deficiency: Apply DAP @ 50kg/acre.")
        
    if nutrient_status.get('Potassium') == 'Low':
        recommendations['fertilizer_recs'].append("Potassium Deficiency: Apply MOP @ 40kg/acre.")

    ph = soil_conditions.get('pH', 7.0)
    if ph < 6.0:
        recommendations['fertilizer_recs'].append("Acidic Soil: Apply Lime to neutralize.")
    elif ph > 8.0:
        recommendations['fertilizer_recs'].append("Alkaline Soil: Apply Gypsum to neutralize.")
    
    oc = soil_conditions.get('OC', 'Medium')
    if oc == 'Low':
        recommendations['fertilizer_recs'].append("Low Organic Carbon: Apply Compost or FYM.")

    if not recommendations['fertilizer_recs']:
        recommendations['fertilizer_recs'].append("Nutrients adequate. Maintain standard practices.")

    # --- 2. Crop Recommendations (Plant Suitable to Grow) ---
    # Simple Logic Mapping based on pH and General Fertility
    # In reality, this would use complex crop-specific requirements.
    
    suitable_crops = []
    
    # Rule 1: Acidic Soil Crops
    if ph < 6.0:
        suitable_crops.append({"name": "Tea", "season": "Year-round", "tips": "Requires good drainage."})
        suitable_crops.append({"name": "Potato", "season": "Rabi (Winter)", "tips": "Earthing up required."})
    # Rule 2: Alkaline Soil Crops
    elif ph > 7.5:
        suitable_crops.append({"name": "Barley", "season": "Rabi (Winter)", "tips": "Tolerant to salinity."})
        suitable_crops.append({"name": "Cotton", "season": "Kharif (Monsoon)", "tips": "Deep plowing recommended."})
    # Rule 3: Neutral Soil (Best for most)
    else:
        suitable_crops.append({"name": "Wheat", "season": "Rabi (Winter)", "tips": "Irrigate at CRI stage."})
        suitable_crops.append({"name": "Rice", "season": "Kharif (Monsoon)", "tips": "Maintain standing water."})
        suitable_crops.append({"name": "Maize", "season": "Kharif/Rabi", "tips": "Ensure no water logging."})

    # Rule 4: Nitrogen Heavy Crops (Avoid if N is Low unless fixed)
    if nutrient_status.get('Nitrogen') == 'Low':
        suitable_crops.append({"name": "Legumes (Nitrogen Fixers)", "season": "Various", "tips": "Helps fix soil Nitrogen naturally."})
    
    recommendations['crop_recs'] = suitable_crops

    # --- 3. Efficiency Tips (Higher Efficiency) ---
    recommendations['efficiency_tips'].append("Soil Testing: Test soil every 3 years.")
    if oc == 'Low':
        recommendations['efficiency_tips'].append("Mulching: Use crop residues to improve Organic Carbon.")
    if ph < 6.0 or ph > 8.0:
        recommendations['efficiency_tips'].append("Amendment Timing: Apply Lime/Gypsum 1 month before sowing.")
        
    recommendations['efficiency_tips'].append("Precision: Apply fertilizers near root zone (Placement method).")

    return recommendations
