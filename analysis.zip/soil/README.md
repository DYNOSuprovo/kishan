# AI-Based Soil Nutrient Deficiency Prediction

## Overview
This project predicts soil nutrient levels (N, P, K) and fertility score using NIR spectral data.

## Folder Structure
- `data/`: Raw data (not included in repo usually)
- `models/`: Trained .joblib models
- `results/`: Metrics and Logs
- `plots/`: Visualizations

## Usage
Run `python main.py` to retrain pipeline.
