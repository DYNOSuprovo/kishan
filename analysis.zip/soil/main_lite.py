import os
import json
import joblib
from data_loader import load_data
from preprocess import preprocess_data
from train_models_lite import train_lite
from fertilizer_rules import get_recommendation

DATA_PATH = r"D:\SIH\SIHV2\data2\NIR spectra Data of Soil samples and fertility properties as matrix X and Y.xlsx"
OUTPUT_DIR = r"D:\SIH\SIHV2\data2\soil"
METRICS_FILE = os.path.join(OUTPUT_DIR, "results", "metrics_lite.json")

def main():
    print("Starting LITE Soil Nutrient Prediction Pipeline...")
    
    try:
        df, input_cols, target_cols = load_data(DATA_PATH)
    except Exception as e:
        print(f"Error loading data: {e}")
        return

    data_dict, scaler = preprocess_data(df, target_cols)
    joblib.dump(scaler, os.path.join(OUTPUT_DIR, "models", "scaler.joblib"))
    
    all_metrics = {}
    
    for target_name, dataset in data_dict.items():
        model, metrics = train_lite(dataset, target_name)
        all_metrics[target_name] = metrics

    with open(METRICS_FILE, 'w') as f:
        json.dump(all_metrics, f, indent=4)
        print(f"\nLite Metrics saved to {METRICS_FILE}")
        
    print("Lite Pipeline Complete!")

if __name__ == "__main__":
    main()
