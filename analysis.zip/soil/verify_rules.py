from fertilizer_rules import get_recommendation

def verify_rules():
    print("--- Verifying Fertilizer Recommendation Rules ---")
    
    test_cases = [
        {
            "nutrient_status": {'Nitrogen': 'Low', 'Phosphorus': 'High', 'Potassium': 'High'},
            "soil_conditions": {'pH': 6.5, 'OC': 'Medium'},
            "expected_partial": "Urea"
        },
        {
            "nutrient_status": {'Nitrogen': 'High', 'Phosphorus': 'Low', 'Potassium': 'High'},
            "soil_conditions": {'pH': 6.5, 'OC': 'Medium'},
            "expected_partial": "DAP"
        },
        {
            "nutrient_status": {'Nitrogen': 'High', 'Phosphorus': 'High', 'Potassium': 'Low'},
            "soil_conditions": {'pH': 6.5, 'OC': 'Medium'},
            "expected_partial": "MOP"
        },
        {
            "nutrient_status": {'Nitrogen': 'Medium', 'Phosphorus': 'Medium', 'Potassium': 'Medium'},
            "soil_conditions": {'pH': 5.5, 'OC': 'Medium'},
            "expected_partial": "Lime"
        },
        {
            "nutrient_status": {'Nitrogen': 'High', 'Phosphorus': 'High', 'Potassium': 'High'},
            "soil_conditions": {'pH': 8.5, 'OC': 'Low'},
            "expected_partial": "Gypsum"
        }
    ]
    
    for i, tc in enumerate(test_cases):
        print(f"\nTest Case {i+1}:")
        print(f"  Inputs: {tc['nutrient_status']}, {tc['soil_conditions']}")
        recs = get_recommendation(tc['nutrient_status'], tc['soil_conditions'])
        print("  Recommendations:")
        for r in recs:
            print(f"    - {r}")
        
        # Validation
        match = any(tc['expected_partial'] in r for r in recs)
        if match:
            print("  [PASS] Expected recommendation found.")
        else:
            print(f"  [FAIL] Expected '{tc['expected_partial']}' NOT found.")

if __name__ == "__main__":
    verify_rules()
