import joblib
import pandas as pd
import numpy as np
import os
from fertilizer_rules import get_recommendation

MODEL_DIR = r"D:\SIH\SIHV2\data2\soil\models"
SCALER_PATH = os.path.join(MODEL_DIR, "scaler.joblib")

def test_model():
    print("--- Manual Model Testing ---")
    
    if not os.path.exists(SCALER_PATH):
        print("Scaler not found. Please run the training pipeline first.")
        return

    try:
        scaler = joblib.load(SCALER_PATH)
    except Exception as e:
        print(f"Error loading scaler: {e}")
        return

    # Simulate an Input (NIR Spectra)
    # Most NIR data has ~1500 columns. We need to match the feature size used during training.
    # We will try to load a sample from the original data if possible, or create a dummy zero/mean vector.
    # Since we can't easily guess the 1500 values, we'll try to load one from the test set if main.py succeeded,
    # or just create a random vector of the correct shape based on scaler mean.
    
    input_dim = scaler.mean_.shape[0]
    print(f"Model expects {input_dim} features.")
    
    # Create a synthetic input close to the mean
    sample_input = scaler.mean_ + np.random.normal(0, 0.1, input_dim)
    
    # Scale it
    sample_scaled = scaler.transform([sample_input])
    
    # Load Models and Predict
    targets = ['Nitrogen', 'Phosphorus', 'Potassium', 'Soil_Fertility_Score']
    # Note: Target names might be slightly different based on data inspection (e.g. 'P (ppm)'),
    # but main.py normalizes them. Let's check what main.py saves.
    # It saves "BEST_{target_name}.joblib"
    
    results = {}
    
    model_files = os.listdir(MODEL_DIR)
    
    for f in model_files:
        if f.startswith("BEST_") and f.endswith(".joblib"):
            target_name = f.replace("BEST_", "").replace(".joblib", "")
            try:
                model = joblib.load(os.path.join(MODEL_DIR, f))
                pred = model.predict(sample_scaled)
                
                # If classification, we need to decode
                # But we didn't save the encoders specifically in main.py separate from data_dict!
                # Wait, main.py didn't save LabelEncoders to disk.
                # This is an oversight. The model returns 0, 1, 2. We need to know what they mean.
                # Usually 0=High, 1=Low, 2=Medium (alphabetical) or similar.
                # I should update main.py to save encoders, OR just print the raw prediction and guess.
                # 'Low', 'Medium', 'High' -> Alphabetical: High(0), Low(1), Medium(2).
                
                results[target_name] = pred[0]
                print(f"Predicted {target_name}: {pred[0]}")
            except Exception as e:
                print(f"Error predicting {target_name}: {e}")

    # Interpretation (assuming alphabetical encoding for demo if encoders missing)
    # High, Low, Medium -> 0, 1, 2
    decoded_results = {}
    mapping = {0: 'High', 1: 'Low', 2: 'Medium'} 
    
    for k, v in results.items():
        if k == 'Soil_Fertility_Score':
            decoded_results[k] = v # Regression
        else:
            # Classification
            if isinstance(v, (int, np.integer)):
                decoded_results[k] = mapping.get(v, str(v))
            else:
                decoded_results[k] = v

    print("\n--- Interpreted Results ---")
    print(decoded_results)
    
    # Recommendation
    print("\n--- Fertilizer & Crop Recommendations ---")
    recs = get_recommendation(decoded_results, {'pH': 6.5, 'OC': 'Medium'})
    
    print("[A] Fertilizer Advice:")
    for r in recs['fertilizer_recs']:
        print(f"   - {r}")
        
    print("\n[B] Suitable Crops:")
    for c in recs['crop_recs']:
        print(f"   - {c['name']} ({c['season']}): {c['tips']}")

    print("\n[C] Efficiency Tips:")
    for t in recs['efficiency_tips']:
        print(f"   - {t}")

if __name__ == "__main__":
    test_model()
