import os
import json
import shutil
import joblib
import pandas as pd
from data_loader import load_data
from preprocess import preprocess_data
from train_models import train_and_evaluate
from evaluate import plot_confusion_matrix, plot_feature_importance
from fertilizer_rules import get_recommendation

# Config
DATA_PATH = r"D:\SIH\SIHV2\data2\NIR spectra Data of Soil samples and fertility properties as matrix X and Y.xlsx"
OUTPUT_DIR = r"D:\SIH\SIHV2\data2\soil"
RESULTS_DIR = os.path.join(OUTPUT_DIR, "results")
METRICS_FILE = os.path.join(RESULTS_DIR, "metrics.json")
ZIP_NAME = os.path.join(OUTPUT_DIR, "soil_project")

def main():
    print("Starting AI-Based Soil Nutrient Prediction Pipeline...")
    
    # 1. Load Data
    try:
        df, input_cols, target_cols = load_data(DATA_PATH)
    except Exception as e:
        print(f"CRITICAL ERROR: {e}")
        return

    # 2. Preprocess
    # We want to predict N, P, K levels + Fertility Score
    # The preprocessor returns a dict of task datasets
    data_dict, scaler = preprocess_data(df, target_cols)
    
    # Save Scaler
    joblib.dump(scaler, os.path.join(OUTPUT_DIR, "models", "scaler.joblib"))
    
    all_metrics = {}
    
    # 3. Train & Evaluate Loop
    for target_name, dataset in data_dict.items():
        if target_name == 'Soil_Fertility_Score':
            print(f"\n--- Processing Regression Target: {target_name} ---")
        else:
            # Classification Targets (N, P, K)
            # Use heuristic to map exact names for "Nice" display
            print(f"\n--- Processing Classification Target: {target_name} ---")
            
        safe_target_name = target_name.replace('/', '_').replace('(', '').replace(')', '').replace(' ', '_')
        
        if 'encoder' in dataset:
            joblib.dump(dataset['encoder'], os.path.join(OUTPUT_DIR, "models", f"{safe_target_name}_encoder.joblib"))
            print(f"Saved encoder for {target_name} as {safe_target_name}")

        best_model, metrics = train_and_evaluate(dataset, safe_target_name)
        
        # We need to ensure the model is also saved with safe name inside train_and_evaluate or we rename it here.
        # train_and_evaluate saves using target_name.
        # So we should probably pass safe_target_name to train_and_evaluate OR modify train_and_evaluate.
        # Let's Modify train_and_evaluate call to use safe_target_name?
        # No, train_and_evaluate prints "Training... for {target_name}".
        # It calls joblib.dump(..., f"{target_name}_{name}.joblib")
        # So I really need to use safe_target_name passed to train_and_evaluate.

        all_metrics[target_name] = metrics
        
        # 4. Plots
        # 4. Plots
        # if dataset['type'] == 'classification':
            # Confusion Matrix on Test Set
            # y_pred = best_model.predict(dataset['X_test_scaled'] if 'X_test_scaled' in dataset else dataset['X_test'])
            # classes = dataset['classes']
            # plot_confusion_matrix(dataset['y_test'], y_pred, classes, f"Confusion Matrix - {target_name}", f"cm_{target_name}.png")
            
            # Feature Importance
            # plot_feature_importance(best_model, dataset['X_train'].columns, f"Feature Importance - {target_name}", f"fi_{target_name}.png")

    # 5. Save Global Metrics
    with open(METRICS_FILE, 'w') as f:
        json.dump(all_metrics, f, indent=4)
        print(f"\nMetrics saved to {METRICS_FILE}")

    # 6. Generate Process Flow Doc
    with open(os.path.join(OUTPUT_DIR, "process_flow.txt"), 'w') as f:
        f.write("AI Soil Nutrient Prediction Process Flow\n")
        f.write("========================================\n\n")
        f.write("1. Data Loading: Ingested Excel, merged Spectral (X) and Soil Properties (Y).\n")
        f.write("2. Preprocessing:\n")
        f.write("   - Handled missing values.\n")
        f.write("   - Derived Nitrogen feature from Organic Carbon if missing.\n")
        f.write("   - Calculated Soil Fertility Score.\n")
        f.write("   - Binned targets (N, P, K) into Low/Medium/High classes.\n")
        f.write("   - Scaled spectral features using StandardScaler.\n")
        f.write("3. Model Training:\n")
        f.write("   - Trained RF, XGB, LGBM, CatBoost for each target.\n")
        f.write("   - Optimized hyperparameters using RandomizedSearchCV.\n")
        f.write("   - Selected best model based on F1-Score/R2.\n")
        f.write("4. Evaluation: Generated matrices, ROC curves, feature importance plots.\n")
        f.write("5. Output: Saved models and metrics for deployment.\n")

    # 7. Create README
    with open(os.path.join(OUTPUT_DIR, "README.md"), 'w') as f:
        f.write("# AI-Based Soil Nutrient Deficiency Prediction\n\n")
        f.write("## Overview\nThis project predicts soil nutrient levels (N, P, K) and fertility score using NIR spectral data.\n\n")
        f.write("## Folder Structure\n- `data/`: Raw data (not included in repo usually)\n- `models/`: Trained .joblib models\n- `results/`: Metrics and Logs\n- `plots/`: Visualizations\n\n")
        f.write("## Usage\nRun `python main.py` to retrain pipeline.\n")

    # 8. Create Recommendation Engine Example Use
    # Demonstrate usage with a random sample from test set
    print("\n--- Generating Sample Recommendations ---")
    recommendations_log = []
    
    # Pick a target to demo (e.g. Nitrogen or first available classification)
    demo_targets = [k for k, v in data_dict.items() if v['type'] == 'classification']
    
    if demo_targets:
        # Simulate a prediction for the first row of test set
        sample_status = {}
        # We need predictions from all best models for one sample.
        # This is a bit complex since models are saved.
        # Simplified: Just grab the y_test label for demonstration script logic.
        
        for t in demo_targets:
            # Decode the label
            encoder = data_dict[t]['encoder']
            y_sample = data_dict[t]['y_test'].iloc[0] # Encoded
            label = encoder.inverse_transform([y_sample])[0]
            
            # Map back to Nutrient Name (strip _Class)
            raw_name = t.replace('_Class', '')
            # Clean name for rules
            if 'Nitrogen' in raw_name or 'N' == raw_name: key = 'Nitrogen'
            elif 'P' in raw_name: key = 'Phosphorus'
            elif 'K' in raw_name: key = 'Potassium'
            else: key = raw_name
            
            sample_status[key] = label
            
        print(f"Sample Status: {sample_status}")
        recs = get_recommendation(sample_status, {'pH': 6.5, 'OC': 'Medium'}) # Mock soil conditions
        print("Recommendations:", recs)
        
        with open(os.path.join(OUTPUT_DIR, "recommendation_engine", "sample_output.txt"), 'w') as f:
            f.write(f"Sample Status: {sample_status}\n")
            f.write("Recommendations:\n")
            for r in recs:
                f.write(f"- {r}\n")

    # 9. ZIP Generation
    print("Creating ZIP archive...")
    shutil.make_archive(ZIP_NAME, 'zip', OUTPUT_DIR)
    print(f"Project exported to {ZIP_NAME}.zip")

if __name__ == "__main__":
    main()
