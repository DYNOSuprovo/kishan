import pandas as pd
import numpy as np
import joblib
import os
import json
from sklearn.model_selection import RandomizedSearchCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, r2_score, mean_squared_error

# Directories
LOG_DIR = r"D:\SIH\SIHV2\data2\soil\logs"
RESULTS_DIR = r"D:\SIH\SIHV2\data2\soil\results"
MODEL_DIR = r"D:\SIH\SIHV2\data2\soil\models"

os.makedirs(LOG_DIR, exist_ok=True)
os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(MODEL_DIR, exist_ok=True)

def train_lite(data_dict, target_name):
    """
    Trains ONLY RandomForest to avoid heavy dependencies (XGB/CatBoost).
    """
    X_train = data_dict['X_train']
    X_test = data_dict['X_test']
    y_train = data_dict['y_train']
    y_test = data_dict['y_test']
    task_type = data_dict['type']
    
    print(f"\n[LITE] Training RandomForest for Target: {target_name} ({task_type})")
    
    model = RandomForestClassifier(n_estimators=50, random_state=42) # Faster
    
    # Simple Fit
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    
    metrics = {}
    if task_type == 'classification':
        acc = accuracy_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred, average='weighted', zero_division=0)
        metrics = {'Accuracy': acc, 'F1': f1}
        print(f"  RandomForest Results: F1={f1:.4f}, Acc={acc:.4f}")
    else:
        # For Regression (Fertility Score), use Classifier for now or skip? 
        # The preprocessor sets type='regression'. RFClassifier won't work on float targets effectively if many unique values.
        # But wait, RandomForestRegressor is in sklearn.ensemble too.
        from sklearn.ensemble import RandomForestRegressor
        model = RandomForestRegressor(n_estimators=50, random_state=42)
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        r2 = r2_score(y_test, y_pred)
        metrics = {'R2': r2}
        print(f"  RandomForest Results: R2={r2:.4f}")

    # Save
    joblib.dump(model, os.path.join(MODEL_DIR, f"BEST_{target_name}.joblib"))
    
    return model, metrics
