import pandas as pd
from fertilizer_rules import get_recommendation

def judge_soil_sample(nitrogen, phosphorus, potassium, ph, oc_level):
    """
    Manually judges a soil sample based on defined criteria.
    Simulates the ML Classification + Rule Engine pipeline.
    
    Criteria (Hypothetical for Demo):
    - Nitrogen (ppm): < 200 (Low), 200-350 (Medium), > 350 (High) (Approx derived values)
    - Phosphorus (ppm): < 20 (Low), 20-50 (Medium), > 50 (High)
    - Potassium (ppm): < 150 (Low), 150-300 (Medium), > 300 (High)
    """
    print(f"\n--- Judging Soil Sample ---")
    print(f"Inputs: N={nitrogen}, P={phosphorus}, K={potassium}, pH={ph}, OC={oc_level}")
    
    # 1. Classification (Mocking the ML/Binning Step)
    status = {}
    
    # Nitrogen Criteria
    if nitrogen < 200: status['Nitrogen'] = 'Low'
    elif nitrogen < 350: status['Nitrogen'] = 'Medium'
    else: status['Nitrogen'] = 'High'
    
    # Phosphorus Criteria
    if phosphorus < 20: status['Phosphorus'] = 'Low'
    elif phosphorus < 50: status['Phosphorus'] = 'Medium'
    else: status['Phosphorus'] = 'High'
    
    # Potassium Criteria
    if potassium < 150: status['Potassium'] = 'Low'
    elif potassium < 300: status['Potassium'] = 'Medium'
    else: status['Potassium'] = 'High'
    
    print(f"1. Classification Result: {status}")
    
    # 2. Recommendation (Rule Engine Step)
    soil_cond = {'pH': ph, 'OC': oc_level}
    recs = get_recommendation(status, soil_cond)
    
    print(f"\n--- 2. ADVISORY REPORT ---")
    
    print("\n[A] FERTILIZER RECOMMENDATIONS:")
    for r in recs['fertilizer_recs']:
        print(f"   • {r}")
        
    print("\n[B] SUITABLE CROPS (Plant to Grow):")
    for c in recs['crop_recs']:
        print(f"   • {c['name']} | Season: {c['season']} | Tip: {c['tips']}")
        
    print("\n[C] EFFICIENCY TIPS:")
    for t in recs['efficiency_tips']:
        print(f"   • {t}")
        
    return status, recs

if __name__ == "__main__":
    # Case 1: Deficient Soil
    judge_soil_sample(nitrogen=150, phosphorus=15, potassium=100, ph=5.5, oc_level='Low')
    
    # Case 2: Healthy Soil
    judge_soil_sample(nitrogen=400, phosphorus=60, potassium=350, ph=7.0, oc_level='High')
    
    # Case 3: Alkaline & Moderate
    judge_soil_sample(nitrogen=250, phosphorus=30, potassium=200, ph=8.2, oc_level='Medium')
