import pandas as pd
import numpy as np
import os

def load_data(file_path):
    """
    Loads the Soil dataset from Excel.
    Expects 'Data X (spectra data)' and 'Data Y (soil properties)' sheets.
    Merges them on 'Num of soil Sample'.
    Derives 'Nitrogen' from 'OC' if missing.
    """
    print(f"Loading data from {file_path}...")
    
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")

    # Load Sheets
    try:
        df_x = pd.read_excel(file_path, sheet_name='Data X (spectra data)')
        df_y = pd.read_excel(file_path, sheet_name='Data Y (soil properties)')
    except Exception as e:
        raise ValueError(f"Error loading sheets: {e}")

    print(f"Spectra Data Shape: {df_x.shape}")
    print(f"Soil Properties Shape: {df_y.shape}")

    # Fix Column Name Mismatch
    if 'No.' in df_y.columns:
        print("Renaming 'No.' to 'Num of soil Sample' in Soil Properties")
        df_y.rename(columns={'No.': 'Num of soil Sample'}, inplace=True)

    # Merge
    # Assuming 'Num of soil Sample' is the common key
    if 'Num of soil Sample' not in df_x.columns or 'Num of soil Sample' not in df_y.columns:
        raise KeyError("Column 'Num of soil Sample' not found in one of the sheets for merging.")

    merged_df = pd.merge(df_x, df_y, on='Num of soil Sample', how='inner')
    print(f"Merged Data Shape: {merged_df.shape}")

    # Handle Missing Nitrogen
    # User requirement: Predict Nitrogen levels.
    # If 'N' or 'Nitrogen' is not in columns, derive it.
    # Common approx: Soil Organic Matter (SOM) = OC * 1.724. Nitrogen ~ SOM / 20 (rough estimate) or just N ~ OC / 10-12.
    # We will use N = OC / 10 as a simple proxy for demonstration if predicting "Deficiency".
    
    target_cols = df_y.columns.tolist()
    # Remove key column from potential targets
    if 'Num of soil Sample' in target_cols:
        target_cols.remove('Num of soil Sample')
        
    nitrogen_col = None
    for col in target_cols:
        if 'nitrogen' in col.lower() or col.strip().lower() == 'n':
            nitrogen_col = col
            break
    
    if nitrogen_col is None:
        print("WARNING: Nitrogen column not found. Deriving 'Nitrogen' from 'OC' (Organic Carbon).")
        # Look for OC column
        oc_col = None
        for col in target_cols:
            if 'oc' in col.lower() or 'organic carbon' in col.lower():
                oc_col = col
                break
        
        if oc_col:
            # Derived Nitrogen (Example conversion)
            merged_df['Nitrogen'] = merged_df[oc_col] / 10.0 # Placeholder conversion
            target_cols.append('Nitrogen')
            print(f"Created 'Nitrogen' column from '{oc_col}'.")
        else:
            print("CRITICAL WARNING: Neither Nitrogen nor Organic Carbon found. Cannot predict Nitrogen.")
    
    return merged_df, df_x.columns.tolist(), target_cols

if __name__ == "__main__":
    # Test
    file_path = r"D:\SIH\SIHV2\data2\NIR spectra Data of Soil samples and fertility properties as matrix X and Y.xlsx"
    if os.path.exists(file_path):
        df, x_cols, y_cols = load_data(file_path)
        print("Data Loaded Successfully.")
        print("Target Columns:", y_cols)
