import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder

def bin_nutrient(value, percentiles):
    """Bins a value into Low, Medium, High based on percentiles."""
    if value < percentiles[0]:
        return 'Low'
    elif value < percentiles[1]:
        return 'Medium'
    else:
        return 'High'

def preprocess_data(df, target_cols, test_size=0.2, random_state=42):
    """
    1. Handle Missing Values (Impute with Mean for simplicity in this demo)
    2. Bin continuous targets (N, P, K) -> Low/Medium/High
    3. Encode Targets
    4. Feature Scaling (StandardScaler for NIR spectra)
    5. Split Train/Test
    """
    print("Preprocessing data...")
    
    # 1. Cleaning
    # Drop columns with too many NaNs if any, or simple imputation
    df = df.fillna(df.mean(numeric_only=True))
    
    # Separation of Features (Spectral) vs Targets (Soil Props)
    # Heuristic: Spectral columns are usually floats around 1000-2500 (colnames are numbers)
    # We will assume all columns that are NOT in target_cols and NOT 'Num of soil Sample' are features.
    
    feature_cols = [c for c in df.columns if c not in target_cols and c != 'Num of soil Sample']
    features = df[feature_cols]
    
    # Calculate Soil Fertility Score (Simplified weighted average of normalized P, K, OC/N)
    # Normalize for score calculation
    targets_numeric = df[target_cols].copy()
    targets_norm = (targets_numeric - targets_numeric.min()) / (targets_numeric.max() - targets_numeric.min())
    
    # Weights: OC/N=0.4, P=0.3, K=0.3 (Hypothetical)
    # Identify Score components
    score_components = []
    if 'Nitrogen' in targets_norm.columns: score_components.append('Nitrogen')
    elif 'OC' in targets_norm.columns: score_components.append('OC') # Use OC if Nitrogen missing numeric mapping
    
    # Look for partial matches for P and K
    p_col = next((c for c in targets_norm.columns if 'P' in c), None) # Simple 'P' might match 'pH'
    # Better P match
    p_col = next((c for c in targets_norm.columns if 'P (ppm)' in c or c=='P'), None)
    
    k_col = next((c for c in targets_norm.columns if 'K (cmol/kg)' in c or c=='K'), None)

    df['Soil_Fertility_Score'] = 0.0
    valid_components = 0
    
    if score_components: 
        df['Soil_Fertility_Score'] += targets_norm[score_components[0]] * 0.4
        valid_components += 1
    if p_col:
        df['Soil_Fertility_Score'] += targets_norm[p_col] * 0.3
        valid_components += 1
    if k_col:
        df['Soil_Fertility_Score'] += targets_norm[k_col] * 0.3
        valid_components += 1
        
    if valid_components > 0:
        df['Soil_Fertility_Score'] = df['Soil_Fertility_Score'] * 100 # Scale to 0-100
    
    print("Soil Fertility Score derived.")

    # 2. Binning Targets
    # We need to bin N, P, K for Classification
    binned_targets = {}
    label_encoders = {}
    
    cols_to_bin = []
    # Identify N, P, K columns again for binning
    # Robust search
    for col in target_cols:
        if any(x in col.lower() for x in ['nitrogen', 'n', 'phosphorus', 'p (', 'potassium', 'k (']):
             # Exclude pH, OC from this specific binning unless requested. Prompt says "Nitrogen, Phosphorus, Potassium"
             if 'pH' in col: continue
             cols_to_bin.append(col)
    
    # Ensure derived Nitrogen is included if it was added to target_cols
    
    print(f"Binning columns: {cols_to_bin}")
    
    for col in cols_to_bin:
        # Calculate percentiles 33% and 66%
        percentiles = np.percentile(df[col], [33, 66])
        new_col_name = f"{col}_Class"
        df[new_col_name] = df[col].apply(lambda x: bin_nutrient(x, percentiles))
        
        # 3. Encoding
        le = LabelEncoder()
        df[new_col_name] = le.fit_transform(df[new_col_name])
        binned_targets[col] = new_col_name
        label_encoders[col] = le
        print(f"Binned & Encoded {col}: {le.classes_}")

    # 4. Scaling Features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(features)
    X = pd.DataFrame(X_scaled, columns=feature_cols)
    
    # 5. Split
    # We return X, and a Dictionary of Ys (one for each target to classify) + The Regression Target (Score)
    
    split_data = {}
    
    # For Classification Targets
    for col, class_col in binned_targets.items():
        y = df[class_col]
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=random_state)
        split_data[col] = {
            'X_train': X_train, 'X_test': X_test, 
            'y_train': y_train, 'y_test': y_test,
            'classes': label_encoders[col].classes_,
            'encoder': label_encoders[col],
            'type': 'classification'
        }
    
    # For Fertility Score (Regression) - Optional/Bonus if time permits classification emphasis
    # Prompt asks "Predict nutrient deficiency levels (Low/Med/High)", so classification is primary.
    # Prompt also says "Soil Fertility Score" as a goal. We should predict it? Or just calculate it?
    # "Predict ... Soil Fertility Score". So we need a regression model for it.
    
    y_score = df['Soil_Fertility_Score']
    X_train_s, X_test_s, y_train_s, y_test_s = train_test_split(X, y_score, test_size=test_size, random_state=random_state)
    split_data['Soil_Fertility_Score'] = {
        'X_train': X_train_s, 'X_test': X_test_s,
        'y_train': y_train_s, 'y_test': y_test_s,
        'type': 'regression'
    }

    return split_data, scaler

if __name__ == "__main__":
    # Test
    # Mock DF
    pass
