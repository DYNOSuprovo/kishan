import pandas as pd
import numpy as np
import joblib
import os
import json
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from xgboost import XGBClassifier, XGBRegressor
from lightgbm import LGBMClassifier, LGBMRegressor
from catboost import CatBoostClassifier, CatBoostRegressor
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, classification_report, mean_squared_error, r2_score

# Ensure logs directory exists
LOG_DIR = r"D:\SIH\SIHV2\data2\soil\logs"
RESULTS_DIR = r"D:\SIH\SIHV2\data2\soil\results"
MODEL_DIR = r"D:\SIH\SIHV2\data2\soil\models"

os.makedirs(LOG_DIR, exist_ok=True)
os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(MODEL_DIR, exist_ok=True)

def get_models(task_type='classification'):
    """Returns a dictionary of models to train."""
    if task_type == 'classification':
        return {
            'RandomForest': RandomForestClassifier(random_state=42),
            'XGBoost': XGBClassifier(use_label_encoder=False, eval_metric='mlogloss', random_state=42),
            'LightGBM': LGBMClassifier(random_state=42, verbose=-1),
            'CatBoost': CatBoostClassifier(verbose=0, random_state=42)
        }
    else:
        return {
            'RandomForest': RandomForestRegressor(random_state=42),
            'XGBoost': XGBRegressor(random_state=42),
            'LightGBM': LGBMRegressor(random_state=42, verbose=-1),
            'CatBoost': CatBoostRegressor(verbose=0, random_state=42)
        }

def get_param_grid(model_name, task_type='classification'):
    """Returns hyperparameter grid for GridSearchCV."""
    if model_name == 'RandomForest':
        return {'n_estimators': [50, 100, 200], 'max_depth': [None, 10, 20]}
    elif model_name == 'XGBoost':
        return {'n_estimators': [50, 100], 'learning_rate': [0.01, 0.1], 'max_depth': [3, 6]}
    elif model_name == 'LightGBM':
        return {'n_estimators': [50, 100], 'learning_rate': [0.01, 0.1], 'num_leaves': [31, 50]}
    elif model_name == 'CatBoost':
        return {'iterations': [100, 200], 'depth': [4, 6], 'learning_rate': [0.01, 0.1]}
    return {}

def train_and_evaluate(data_dict, target_name):
    """
    Trains multiple models for a specific target (e.g., Nitrogen).
    Selects best model based on F1-Score (Classification) or R2 (Regression).
    """
    X_train = data_dict['X_train']
    X_test = data_dict['X_test']
    y_train = data_dict['y_train']
    y_test = data_dict['y_test']
    task_type = data_dict['type']
    
    print(f"\n--- Training models for Target: {target_name} ({task_type}) ---")
    
    models = get_models(task_type)
    best_model = None
    best_score = -np.inf
    best_model_name = ""
    model_metrics = {}
    
    for name, model in models.items():
        print(f"Training {name}...")
        param_grid = get_param_grid(name, task_type)
        
        # Using RandomizedSearchCV for speed in this demo, usually GridSearchCV
        search = RandomizedSearchCV(model, param_grid, n_iter=5, cv=3, scoring='f1_weighted' if task_type == 'classification' else 'r2', n_jobs=1, random_state=42)
        
        try:
            search.fit(X_train, y_train)
            best_est = search.best_estimator_
            
            y_pred = best_est.predict(X_test)
            
            metrics = {}
            if task_type == 'classification':
                acc = accuracy_score(y_test, y_pred)
                prec = precision_score(y_test, y_pred, average='weighted', zero_division=0)
                rec = recall_score(y_test, y_pred, average='weighted', zero_division=0)
                f1 = f1_score(y_test, y_pred, average='weighted', zero_division=0)
                
                try:
                    y_prob = best_est.predict_proba(X_test)
                    if len(np.unique(y_test)) == 2:
                        roc = roc_auc_score(y_test, y_prob[:, 1])
                    else:
                        roc = roc_auc_score(y_test, y_prob, multi_class='ovr')
                except:
                    roc = 0.0
                
                metrics = {'Accuracy': acc, 'Precision': prec, 'Recall': rec, 'F1': f1, 'ROC_AUC': roc}
                score = f1
                print(f"  {name} Results: F1={f1:.4f}, Acc={acc:.4f}")
                
            else: # Regression
                mse = mean_squared_error(y_test, y_pred)
                r2 = r2_score(y_test, y_pred)
                metrics = {'MSE': mse, 'R2': r2}
                score = r2
                print(f"  {name} Results: R2={r2:.4f}, MSE={mse:.4f}")
            
            model_metrics[name] = metrics
            
            # Save Model
            joblib.dump(best_est, os.path.join(MODEL_DIR, f"{target_name}_{name}.joblib"))
            
            if score > best_score:
                best_score = score
                best_model = best_est
                best_model_name = name
                
        except Exception as e:
            print(f"Failed to train {name}: {e}")

    print(f"Best Model for {target_name}: {best_model_name} (Score: {best_score:.4f})")
    
    # Save Best Model as the 'Production' model for this target
    joblib.dump(best_model, os.path.join(MODEL_DIR, f"BEST_{target_name}.joblib"))
    
    # Log results
    with open(os.path.join(LOG_DIR, f"{target_name}_training_log.txt"), "w") as f:
        f.write(f"Training Log for {target_name}\n")
        f.write(json.dumps(model_metrics, indent=4))
        
    return best_model, model_metrics

if __name__ == "__main__":
    pass
