import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
import os
import joblib
from sklearn.metrics import confusion_matrix, roc_curve, auc

PLOT_DIR = r"D:\SIH\SIHV2\data2\soil\plots"
os.makedirs(PLOT_DIR, exist_ok=True)

def plot_confusion_matrix(y_true, y_pred, classes, title, filename):
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=classes, yticklabels=classes)
    plt.title(title)
    plt.ylabel('True Label')
    plt.xlabel('Predicted Label')
    plt.tight_layout()
    plt.savefig(os.path.join(PLOT_DIR, filename))
    plt.close()

def plot_feature_importance(model, feature_names, title, filename):
    # Check if model has feature_importances_
    if hasattr(model, 'feature_importances_'):
        importances = model.feature_importances_
        indices = np.argsort(importances)[::-1][:20] # Top 20
        
        plt.figure(figsize=(10, 6))
        plt.title(title)
        plt.bar(range(len(indices)), importances[indices], align='center')
        plt.xticks(range(len(indices)), [feature_names[i] for i in indices], rotation=90)
        plt.tight_layout()
        plt.savefig(os.path.join(PLOT_DIR, filename))
        plt.close()

def generate_report(results_dict, target_name):
    # Currently just prints or could save to PDF
    pass

if __name__ == "__main__":
    pass
