import pandas as pd
import os

file_path = r"D:\SIH\SIHV2\data2\NIR spectra Data of Soil samples and fertility properties as matrix X and Y.xlsx"
try:
    df_x = pd.read_excel(file_path, sheet_name='Data X (spectra data)')
    df_y = pd.read_excel(file_path, sheet_name='Data Y (soil properties)')
    
    print("Sheet X Columns:")
    print(df_x.columns.tolist()[:10]) # Print first 10
    
    print("\nSheet Y Columns:")
    print([repr(c) for c in df_y.columns])
    
    if 'Num of soil Sample' in df_x.columns:
        print("Found in X")
    else:
        print("NOT Found in X")
        
    if 'Num of soil Sample' in df_y.columns:
        print("Found in Y")
    else:
        print("NOT Found in Y")
    
except Exception as e:
    print(e)
