# 🌱 Agricultural AI Analysis System

> An AI-powered system for soil nutrient analysis and crop medicine recommendation

This repository contains two main AI/ML modules designed to assist farmers in making data-driven decisions for better crop management:

1. **Soil Nutrient Prediction System** - Analyzes NIR spectral data to predict soil nutrient levels
2. **Medicine Recommendation System** - Recommends appropriate medicines/treatments for crop diseases

---

## 📁 Project Structure

```
data2/
├── soil/                           # Soil Nutrient Prediction Module
│   ├── main.py                     # Main pipeline orchestrator
│   ├── data_loader.py              # Data loading & preprocessing from Excel
│   ├── preprocess.py               # Feature engineering & data transformation
│   ├── train_models.py             # Model training with hyperparameter tuning
│   ├── evaluate.py                 # Model evaluation utilities
│   ├── fertilizer_rules.py         # Rule-based recommendation engine
│   ├── judge_soil.py               # Manual soil sample classification
│   ├── test_input.py               # Input testing utilities
│   ├── requirements.txt            # Python dependencies
│   ├── models/                     # Trained ML models (.joblib)
│   ├── logs/                       # Training logs
│   ├── results/                    # Metrics and evaluation results
│   └── plots/                      # Visualization outputs
│
├── medicine/                       # Medicine Recommendation Module
│   ├── train_medicine.py           # Model training script
│   ├── medicine_data.csv           # Training dataset
│   └── models/                     # Trained models & encoders
│
├── predict.py                      # Interactive Soil Advisory Tool (CLI)
├── analysis.ipynb                  # Comprehensive Data Analysis Notebook
├── run_analysis.py                 # Automated Analysis Script
├── NIR spectra Data of Soil samples...xlsx   # Raw soil spectral data
└── data_info.txt                   # Data documentation
```

---

## 🚀 NEW: Interactive Tools

### 1. Soil Advisory Tool (`predict.py`)
An interactive command-line tool that generates a comprehensive advisory report based on manual soil test inputs.

**Usage:**
```bash
python predict.py
```
**Features:**
- Accepts N, P, K, pH, and OC inputs
- Diagnoses nutrient deficiencies
- Recommends specific fertilizers (Urea, DAP, MOP, etc.)
- Suggests suitable crops based on soil conditions
- Provides efficiency tips

### 2. Comprehensive Analysis (`analysis.ipynb`)
A Jupyter Notebook for end-to-end data analysis, preprocessing, and model benchmarking.

**Features:**
- Loads and processes NIR spectral data
- Trains and compares **8+ models** (RandomForest, XGBoost, LightGBM, CatBoost, SVM, KNN, GradientBoosting, MLP)
- Automatically selects and saves the best model for each target
- Visualizes performance metrics

**Automated Execution:**
You can also run the analysis logic as a script:
```bash
python run_analysis.py
```

---

## 🌍 Module 1: Soil Nutrient Prediction System

### Overview
The Soil Nutrient Prediction System uses **Near-Infrared (NIR) spectroscopy data** to predict soil nutrient deficiency levels (Nitrogen, Phosphorus, Potassium) and calculate an overall **Soil Fertility Score**.

### Features
- **Multi-Target Classification**: Predicts N, P, K levels as Low/Medium/High
- **Fertility Score Regression**: Calculates a 0-100 fertility score
- **Extended Model Search**: Now compares KNN, SVM, MLP, GradientBoosting, and more.
- **Hyperparameter Optimization**: Uses RandomizedSearchCV for tuning
- **Rule-Based Recommendations**: Provides actionable fertilizer and crop advice

### Data Pipeline

```mermaid
graph LR
    A[NIR Spectral Data] --> B[Data Loader]
    B --> C[Preprocessing]
    C --> D[Feature Scaling]
    D --> E[Train/Test Split]
    E --> F[Model Training (Expanded)]
    F --> G[Best Model Selection]
    G --> H[Recommendation Engine]
```

### Process Flow
1. **Data Loading**: Ingests Excel data, merges Spectral (X) and Soil Properties (Y)
2. **Preprocessing**:
   - Handles missing values
   - Derives Nitrogen from Organic Carbon if missing
   - Calculates Soil Fertility Score
   - Bins targets (N, P, K) into Low/Medium/High classes
   - Scales spectral features using StandardScaler
3. **Model Training**:
   - Trains RandomForest, XGBoost, LightGBM, CatBoost, **SVM**, **KNN**, **MLP**, **GradientBoosting** for each target
   - Optimizes hyperparameters using RandomizedSearchCV
   - **Key Finding**: KNN often outperforms tree-based models for high-dimensional spectral data with limited samples.
4. **Output**: Saves best models to `models/`

### Usage

```bash
cd soil
pip install -r requirements.txt
python main.py
```

### Trained Models
The system trains and saves multiple models for each target:
- `BEST_<target>.joblib` - Best performing model for each target (e.g., `BEST_N.joblib`)
- `<target>_RandomForest.joblib`
- `<target>_XGBoost.joblib`
- ...and others.

### Recommendation Engine
The `fertilizer_rules.py` module provides intelligent recommendations based on soil analysis:

#### Fertilizer Recommendations
| Condition | Recommendation |
|-----------|----------------|
| Nitrogen Low | Apply Urea @ 60kg/acre |
| Nitrogen Medium | Apply Urea @ 30kg/acre (maintenance) |
| Phosphorus Low | Apply DAP @ 50kg/acre |
| Potassium Low | Apply MOP @ 40kg/acre |
| pH < 6.0 | Apply Lime to neutralize acidic soil |
| pH > 8.0 | Apply Gypsum to neutralize alkaline soil |
| Low Organic Carbon | Apply Compost or FYM |

#### Crop Recommendations
| Soil Condition | Suitable Crops |
|----------------|----------------|
| Acidic (pH < 6) | Tea, Potato |
| Alkaline (pH > 7.5) | Barley, Cotton |
| Neutral (pH 6-7.5) | Wheat, Rice, Maize |
| Low Nitrogen | Legumes (Nitrogen Fixers) |

---

## 💊 Module 2: Medicine Recommendation System

### Overview
The Medicine Recommendation System uses machine learning to predict the most appropriate medicine/treatment for crop diseases.

### Features
- **Crop-Disease Mapping**: Recommends medicines based on crop type and disease
- **Multi-Model Benchmarking**: Compares SGD, RandomForest, SVM, KNN, MLP, XGBoost
- **Label Encoding**: Handles categorical crop and disease inputs
- **Scalable**: Easy to extend with new crops and diseases

### Usage

```bash
cd medicine
python train_medicine.py
```

### Trained Models
- `medicine_model.joblib` - Best performing model
- `medicine_scaler.joblib` - StandardScaler for feature normalization
- Encoders: `le_crop.joblib`, `le_disease.joblib`, `le_medicine.joblib`

---

## 📊 Dependencies

### Soil Module
```
pandas
numpy
scikit-learn
xgboost
lightgbm
catboost
matplotlib
seaborn
openpyxl
joblib
shap
```

### Medicine Module
```
pandas
scikit-learn
joblib
```

---

## 🚀 Quick Start

### Prerequisites
- Python 3.8+
- pip package manager

### Installation

```bash
# Clone/download the repository
cd data2

# Install dependencies
pip install pandas numpy scikit-learn xgboost lightgbm catboost matplotlib seaborn openpyxl joblib

# Run interactive advisor
python predict.py

# Run full analysis
python run_analysis.py
```

---

## 🔧 API Integration

Both modules can be integrated into a FastAPI backend for web/mobile applications:

### Soil Analysis API Endpoint
```python
@app.post("/api/analyze-soil")
async def analyze_soil(nitrogen: float, phosphorus: float, potassium: float, ph: float, oc: str):
    # Load model and predict
    # Return recommendations
    pass
```

### Medicine Recommendation API Endpoint
```python
@app.post("/api/recommend-medicine")
async def recommend_medicine(crop: str, disease: str):
    # Load model and predict
    # Return recommended medicine with dosage info
    pass
```

---

## 📈 Performance Metrics

### Soil Module
- Classification targets evaluated using: **Accuracy, Precision, Recall, F1-Score, ROC-AUC**
- Regression target (Fertility Score) evaluated using: **MSE, R²**
- Models compared: RandomForest, XGBoost, LightGBM, CatBoost, SVM, KNN, MLP, GradientBoosting
- Best models selected per target and saved with `BEST_` prefix

### Medicine Module
- Benchmarked against SGD, RandomForest, SVM, KNN, MLP
- Metric: Accuracy / Log Loss

---

## 📝 License

This project is developed as part of the Smart India Hackathon (SIH) initiative for agricultural technology advancement.

---

## 👥 Contributors

Developed for **KisanConnect Hub** - An AI-powered agricultural assistance platform.

---

## 🔗 Related Projects

- [KisanConnect Hub Main Application](../kisanconnect-hub-main/)
- [Wheat Disease Detection Module](../wheat_analysis_app/)
